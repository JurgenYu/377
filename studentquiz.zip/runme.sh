sudo apt install python3
python3 ./Client.py