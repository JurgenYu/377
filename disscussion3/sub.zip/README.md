Two Commands Has been added into the system:

1.yes:
    type "yes" into the command and it infinitely writes 'y' into the stdout. Works effectively when inserting 'y' command for comfirmation with "cat"

2.clear:
    type "clear" into the command and the screen can be cleared with a new input prompt. Works similarly in orther unix based systems

Both commands does not take an argument