#include <map>
#include <queue>
#include <set>
#include <string>

#include "inverter.h"

using namespace std;

string build_inverted_index(string filename) { return ""; }
